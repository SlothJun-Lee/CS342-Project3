import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.function.Consumer;
import java.net.SocketException;
import java.io.EOFException;



public class Client extends Thread {
	Socket socketClient;
	ObjectOutputStream out;
	ObjectInputStream in;
	private Consumer<Message> callback;

	Client(Consumer<Message> call) {
		callback = call;
	}

	public void run() {
		try {
			socketClient = new Socket("127.0.0.1", 5555);
			out = new ObjectOutputStream(socketClient.getOutputStream());
			in = new ObjectInputStream(socketClient.getInputStream());
			socketClient.setTcpNoDelay(true);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}

		while (!Thread.currentThread().isInterrupted()) {  // 명확한 쓰레드 종료 처리 추가
			try {
				Message message = (Message) in.readObject();
				System.out.println("📥 RECEIVED: type=" + message.type + ", sender=" + message.sender + ", username=" + message.username);
				callback.accept(message);
			} catch (SocketException e) {
				System.out.println("✅ 연결이 닫혔습니다. 정상적으로 쓰레드를 종료합니다.");
				break;  // SocketException 발생 시 루프 종료
			} catch (EOFException e) {
				System.out.println("✅ 서버 연결 종료(EOF). 쓰레드를 종료합니다.");
				break;  // 서버가 종료된 경우 (정상 종료)
			} catch (Exception e) {
				e.printStackTrace();
				break;
			}
		}

		closeConnection();  // 연결을 완전히 정리해 주기
		System.out.println("🔌 클라이언트 쓰레드 정상 종료.");
	}

	public void send(Message data) {
		try {
			out.writeObject(data);
			out.flush();                              // 즉시 전송

			/* ▼ 디버그 로그 */
			System.out.println(
					">>> SENT  "+data.type+
							"  user="+data.username+
							"  msg="+data.message);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void inviteFriend(String from, String to) {
		send(Message.fromInvite(MessageType.FRIEND_REQUEST, from, to));
	}

	public void respondToInvite(boolean accept, String from, String to) {
		MessageType type = accept ? MessageType.FRIEND_ACCEPT
				: MessageType.FRIEND_DECLINE;
		send(Message.fromInvite(type, from, to));  // 꼭 fromInvite 사용
	}

	public void sendLogout(String username) {
		Message logoutMsg = new Message();
		logoutMsg.type = MessageType.DISCONNECT;
		logoutMsg.username = username;
		send(logoutMsg);
	}

	public void closeConnection() {
		try {
			if (socketClient != null && !socketClient.isClosed()) {
				socketClient.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendMove(int col, String username) {
		Message move = new Message();
		move.type = MessageType.MOVE_MADE;
		move.username = username;
		move.sender = username;
		move.message = String.valueOf(col);
		send(move);
	}
}

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.Map;
import java.util.HashMap;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GuiClient extends Application {

	/* --------------------------------------------------
	 *  NETWORK & WINDOW STATE
	 * -------------------------------------------------- */
	private Client clientConnection;
	private Stage  window;
	private Scene  loginScene, mainMenuScene, statsScene;

	/* --------------------------------------------------
	 *  LOGIN SCENE CONTROLS
	 * -------------------------------------------------- */
	private TextField     userField = new TextField();
	private PasswordField passField = new PasswordField();
	private Label         statusLabel = new Label();

	/* --------------------------------------------------
	 *  MAIN/GAME LABELS
	 * -------------------------------------------------- */
	private final Label selfLabel  = new Label();
	private final Label timerLabel = new Label("Time: 40");
	private final Label oppLabel   = new Label();
	private final Label nameLbl    = new Label();

	/* -------------------------------------------------- */
	private String  currentUsername;
	private String  currentOpponent;
	private final boolean[] isMyTurn = new boolean[1];   // mutable in lambdas
	private boolean gameDone = false;

	private final StackPane[][] cellPane = new StackPane[6][7];
	private       Circle[][]    discs;
	private Button surrenderBtn;
	/*  Chat  */
	private final ListView<String> chatList   = new ListView<>();
	private final TextField        inputField = new TextField();

	/*  Timer  */
	private final Integer[] timeLeft = new Integer[1];
	private final Timeline[] clock   = new Timeline[1];

	/*  Colours  */
	private Color myColor, oppColor;

	/*  Friends / Online lists  */
	private final ListView<String> friendsList      = new ListView<>();
	private final ListView<String> onlineStatusList = new ListView<>();

	public static void main(String[] args) { launch(args); }
	private final Map<String, Boolean> friendStatus = new HashMap<>();








	/* --------------------------------------------------
	 *  Small DTO for parsed stats (Java‑8 safe)
	 * -------------------------------------------------- */
	private static class StatsParsed {
		final int wins, losses;                 // totals
		final List<String[]> recent;            // up to 5 rows  [winFlag, opponent]
		StatsParsed(int w,int l,List<String[]> r){ wins=w; losses=l; recent=r; }
	}

	private void setLight(String user, boolean online) {
		friendStatus.put(user, online);
		friendsList.refresh();   // UI 즉시 갱신
	}

	@Override public void start(Stage stage){
		this.window = stage;
		buildLoginScene();
		buildMainMenuScene();

		clientConnection = new Client(msg -> Platform.runLater(() -> onServer(msg)));
		clientConnection.start();

		window.setScene(loginScene);
		window.setTitle("Connect Four");
		window.show();
	}

	/* -------------------------------- */
	/*          SCENE BUILDERS          */
	/* -------------------------------- */
	private void buildLoginScene(){
		Button loginBtn  = new Button("Log In");
		loginBtn.setOnAction(e -> auth(false));

		Button signupBtn = new Button("Sign Up");
		signupBtn.setOnAction(e -> auth(true));

		VBox box = new VBox(10, statusLabel,
				new Label("User Name:"), userField,
				new Label("Password:"), passField,
				loginBtn, signupBtn);

		box.setAlignment(Pos.CENTER);
		box.setPadding(new Insets(20));
		loginScene = new Scene(box,300,300);
	}

	private void buildMainMenuScene() {
		nameLbl.setText("User: " + currentUsername);

		// 버튼 명확히 정의
		Button friendPlayBtn = new Button("Play with a friend");
		Button randomMatchBtn = new Button("Random Match");
		Button aiPlayBtn = new Button("Play AI");
		Button statsBtn = new Button("📊 View Stats");
		Button logoutBtn = new Button("Log Out");

		// 각 버튼 액션 설정
		friendPlayBtn.setOnAction(e -> {
			String selectedFriend = friendsList.getSelectionModel().getSelectedItem();

			if (selectedFriend == null) {
				Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a friend first.");
				alert.setHeaderText("No friend selected");
				alert.showAndWait();
				return;
			}

			// ⚠️ 반드시 Message를 이 생성자로 명확히 생성해야 함!
			Message inviteMsg = Message.fromInvite(MessageType.MATCH_REQUEST, currentUsername, selectedFriend);

			clientConnection.send(inviteMsg);

			Alert sentAlert = new Alert(Alert.AlertType.INFORMATION, "Game invitation sent to " + selectedFriend);
			sentAlert.setHeaderText("Invitation Sent");
			sentAlert.show();
		});

		randomMatchBtn.setOnAction(e ->
				clientConnection.send(Message.fromMatchRequest(currentUsername))
		);

		aiPlayBtn.setOnAction(e -> {
			// AI 플레이 로직 추가 예정 (별도 구현 필요)
			Alert alert = new Alert(Alert.AlertType.INFORMATION, "AI 플레이는 아직 구현되지 않았습니다.");
			alert.setHeaderText("AI Play");
			alert.show();
		});

		statsBtn.setOnAction(e ->
				clientConnection.send(new Message(MessageType.STATS_REQUEST, currentUsername, ""))
		);

		logoutBtn.setOnAction(e -> {
			if (clientConnection != null) {
				clientConnection.sendLogout(currentUsername);
				// 연결 종료 명령을 삭제 (연결 유지)
			}
			friendStatus.clear();
			friendsList.getItems().clear();
			friendsList.refresh();
			window.setScene(loginScene);
		});

		// 왼쪽 버튼 영역 레이아웃 구성
		VBox leftButtons = new VBox(15,
				nameLbl,
				friendPlayBtn,
				randomMatchBtn,
				aiPlayBtn,
				statsBtn,
				logoutBtn);
		leftButtons.setPadding(new Insets(15));
		leftButtons.setAlignment(Pos.TOP_CENTER);

		// 오른쪽 친구 추가 및 친구 목록 영역 구성
		TextField addFriendField = new TextField();
		addFriendField.setPromptText("Add a friend");
		Button addFriendBtn = new Button("+");
		addFriendBtn.setOnAction(e -> {
			String friendName = addFriendField.getText().trim();
			if (!friendName.isEmpty()) {
				clientConnection.send(Message.fromInvite(MessageType.FRIEND_REQUEST, currentUsername, friendName));
				addFriendField.clear();
			}
		});

		HBox addFriendBox = new HBox(addFriendField, addFriendBtn);
		addFriendBox.setSpacing(10);

		// 친구 목록 UI (상태 표시 추가)
		friendsList.setCellFactory(lv -> new ListCell<String>() {
			private final Circle statusCircle = new Circle(5);

			@Override
			protected void updateItem(String friend, boolean empty) {
				super.updateItem(friend, empty);
				if (empty || friend == null) {
					setText(null);
					setGraphic(null);
					return;
				}
				boolean isOnline = friendStatus.getOrDefault(friend, false);
				statusCircle.setFill(isOnline ? Color.LIMEGREEN : Color.RED);
				setText(friend);
				setGraphic(statusCircle);
			}
		});

		VBox rightFriendArea = new VBox(10,
				addFriendBox,
				friendsList);
		rightFriendArea.setPadding(new Insets(15));

		// 최종 MainMenu 구성
		HBox mainMenuRoot = new HBox(20, leftButtons, rightFriendArea);
		mainMenuScene = new Scene(mainMenuRoot, 700, 500);
	}




	private StatsParsed parseStats(String payload){
		if(payload==null || payload.isEmpty()) return new StatsParsed(0,0,new ArrayList<>());
		String[] parts  = payload.split(";");
		String[] totals = parts[0].split(",");
		int wins = Integer.parseInt(totals[0]);
		int losses = Integer.parseInt(totals[1]);
		List<String[]> recent = new ArrayList<>();
		for(int i=1;i<parts.length;i++){
			String[] row = parts[i].split(",",2);
			if(row.length==2) recent.add(row);
		}
		return new StatsParsed(wins,losses,recent);
	}

	private void buildStatsScene(StatsParsed sp){
		double rate = (sp.wins + sp.losses) == 0 ? 0.0 : sp.wins * 100.0 / (sp.wins + sp.losses);
		Label hdr = new Label("Stats for " + currentUsername);
		Label totals = new Label("Wins: " + sp.wins + "    Losses: " + sp.losses + "    Win-rate: " + String.format("%.1f", rate) + "% (recent 5 below)");

		TableView<String[]> tbl = new TableView<>();
		tbl.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		TableColumn<String[], String> colRes = new TableColumn<>("W/L");
		colRes.setCellValueFactory(d -> new SimpleStringProperty("true".equals(d.getValue()[0]) ? "Win" : "Loss"));
		TableColumn<String[], String> colOpp = new TableColumn<>("Opponent");
		colOpp.setCellValueFactory(d -> new SimpleStringProperty(d.getValue()[1]));

		tbl.getColumns().addAll(colRes, colOpp);
		tbl.getItems().setAll(sp.recent);

		Button back = new Button("🔙 Back to Main");
		back.setOnAction(e -> window.setScene(mainMenuScene));

		VBox root = new VBox(12, hdr, totals, tbl, back);
		root.setPadding(new Insets(15));
		root.setAlignment(Pos.CENTER);
		statsScene = new Scene(root, 450, 400);
	}
	/* -------------------------------- */
	/*       SERVER MESSAGE HANDLER     */
	/* -------------------------------- */
	private void onServer(Message m) {
		switch (m.type) {
			case LOGIN_SUCCESS:
				currentUsername = m.username;
				statusLabel.setText("");
				userField.clear();
				passField.clear();
				nameLbl.setText("User: "+currentUsername);
				window.setScene(mainMenuScene);
				break;
			case LOGIN_FAIL:
				System.out.println("[클라이언트 수신] LOGIN_FAIL 메시지: " + m.message);
				statusLabel.setText(m.message);
				break;
			case SIGNUP_SUCCESS:
				currentUsername = m.username;
				statusLabel.setText("");
				userField.clear();
				passField.clear();
				nameLbl.setText("User: " + currentUsername);
				window.setScene(mainMenuScene);
				break;
			case SIGNUP_FAIL:
				System.out.println("[클라이언트 수신] SIGNUP_FAIL 메시지: " + m.message);
				statusLabel.setText(m.message);
				break;
			case MATCH_REQUEST:
				Platform.runLater(() -> {
					Alert inviteAlert = new Alert(Alert.AlertType.CONFIRMATION);
					inviteAlert.setTitle("Game Invitation");
					inviteAlert.setHeaderText(m.sender + " has invited you to a game!");
					inviteAlert.setContentText("Would you like to accept?");

					Optional<ButtonType> result = inviteAlert.showAndWait();
					if (result.isPresent() && result.get() == ButtonType.OK) {
						// 게임 초대 수락 (서버에 수락 알림)
						Message acceptMsg = new Message();
						acceptMsg.type = MessageType.MATCH_ACCEPT;
						acceptMsg.username = currentUsername;
						acceptMsg.sender = m.sender; // 초대한 사람
						clientConnection.send(acceptMsg);
					} else {
						// 게임 초대 거절 (서버에 거절 알림)
						Message declineMsg = new Message();
						declineMsg.type = MessageType.MATCH_DECLINE;
						declineMsg.username = currentUsername;
						declineMsg.sender = m.sender; // 초대한 사람
						clientConnection.send(declineMsg);
					}
				});
				break;
			case MATCH_FOUND:
				System.out.println("### MATCH_FOUND: me=" + currentUsername +
						" opp=" + m.message + " first=" + (m.recipient==1));
				closeGameOverWindows();
				String opponent = m.message.equals(currentUsername) ? m.username : m.message;

				boolean first = m.recipient == 1;
				myColor = first ? Color.RED : Color.BLUE;
				oppColor = first ? Color.BLUE : Color.RED;

				Platform.runLater(() -> {
					gameScene(currentUsername, opponent, first); // 반드시 먼저 호출 (초기화 먼저!)
					setBoard(first);                             // 그 다음 상태 설정
					if (first) {
						startTimer();
					}
				});
				break;
			case YOUR_TURN:
				isMyTurn[0] = true;
				startTimer();
				setBoard(true);
				break;
			case MOVE_MADE:
				opponentMove(m.message);
				break;
			case GAME_WIN:
				localEnd(m.username.equals(currentUsername) ? "You win!" : "You lose!");
				break;
			case GAME_DRAW:
				localEnd("Draw!");
				break;
			case FRIEND_REQUEST:
				handleFriendRequest(m);
				break;

			case REMATCH_REQUEST:
				Platform.runLater(() -> {
					Alert rematchAlert = new Alert(Alert.AlertType.CONFIRMATION);
					rematchAlert.setTitle("Rematch Request");
					rematchAlert.setHeaderText(null);
					rematchAlert.setContentText(m.sender + " wants to play again. Accept?");

					Optional<ButtonType> result = rematchAlert.showAndWait();
					if (result.isPresent() && result.get() == ButtonType.OK) {
						Message acceptRematch = new Message();
						acceptRematch.type = MessageType.REMATCH_ACCEPT;
						acceptRematch.sender = currentUsername;
						acceptRematch.message = m.sender; // 상대방 이름
						clientConnection.send(acceptRematch);
					} else {
						Message declineMatch = new Message();
						declineMatch.type = MessageType.MATCH_DECLINE;
						declineMatch.sender = currentUsername;
						declineMatch.message = m.sender; // 상대방 이름
						clientConnection.send(declineMatch);
					}
				});
				break;

			case FRIEND_ACCEPT:
				String acceptedFriend = m.username.equals(currentUsername) ? m.message : m.username;
				if (!friendsList.getItems().contains(acceptedFriend))
					friendsList.getItems().add(acceptedFriend);
				setLight(acceptedFriend, true);
				break;

			case FRIEND_DECLINE:
				new Alert(Alert.AlertType.INFORMATION,
						m.username + " declined your request.").show();
				break;
			case FRIEND_LIST: // 👈 친구 목록 전용 타입
				friendsList.getItems().clear();
				friendsList.getItems().addAll(m.gameHistory);
				for (String friend : m.gameHistory) {
					friendStatus.put(friend, false);
				}
				friendsList.refresh();
				break;
			case ONLINE_UPDATE:
				friendStatus.put(m.username, m.recipient == 1);
				System.out.println("🔄 친구 온라인 상태 업데이트: " + m.username + " → " + (m.recipient == 1 ? "온라인" : "오프라인"));
				friendsList.refresh();  // UI 즉시 갱신 (⭐️ 매우 중요!)
				break;
			case TEXT:
				String sender = (m.username != null ? m.username : "?"); // ★★★ username으로 표시
				String msg = (m.message != null ? m.message : "[null]");
				chatList.getItems().add(sender + ": " + msg);
				break;
			case STATS_REPLY: // 현재 임시로 사용한 타입
				if (m.gameHistory != null) {
					friendsList.getItems().clear();
					friendsList.getItems().addAll(m.gameHistory);

					// 온라인 상태 초기화
					for (String friend : m.gameHistory) {
						friendStatus.put(friend, false);
					}
					friendsList.refresh();
				} else {
					buildStatsScene(parseStats(m.message));
					window.setScene(statsScene);
				}
				break;
			default:
				break;
		}
	}

	private void sendChat(String txt) {
		if (txt.trim().isEmpty()) return;

		chatList.getItems().add(currentUsername + ": " + txt);

		Message msg = new Message();
		msg.type = MessageType.TEXT;
		msg.username = currentUsername;
		msg.message = txt;

		new Thread(() -> clientConnection.send(msg)).start();
	}
	private void handleFriendRequest(Message m) {
		System.out.println("🚨 친구 요청 Alert 창을 띄우기 직전. sender = " + m.sender);
		Platform.runLater(() -> {
			Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
			alert.setTitle("Friend Request");
			alert.setHeaderText(m.sender + " sent you a friend request.");
			alert.setContentText("Accept this friend request?");

			Optional<ButtonType> result = alert.showAndWait();
			if (result.isPresent() && result.get() == ButtonType.OK) {
				Message acceptMsg = new Message();
				acceptMsg.type = MessageType.FRIEND_ACCEPT;
				acceptMsg.username = currentUsername;
				acceptMsg.message = m.sender;
				clientConnection.send(acceptMsg);
			} else {
				Message declineMsg = new Message();
				declineMsg.type = MessageType.FRIEND_DECLINE;
				declineMsg.username = currentUsername;
				declineMsg.message = m.sender;
				clientConnection.send(declineMsg);
			}
		});
	}


	private void closeGameOverWindows() {
		List<javafx.stage.Window> snapshot =
				new ArrayList<>(javafx.stage.Window.getWindows());
		for (javafx.stage.Window w : snapshot) {
			if (w instanceof Stage && "Game Over".equals(((Stage) w).getTitle())) {
				((Stage) w).close();
			}
		}
	}

	private void handleRematchPrompt(Message m){
		Platform.runLater(() -> {
			Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
			confirm.setTitle("Rematch Request");
			confirm.setHeaderText(m.username+" wants a rematch!");
			confirm.setContentText("Do you want to play again?");
			Optional<ButtonType> res = confirm.showAndWait();
			if(res.isPresent() && res.get()==ButtonType.OK){
				// ▲ 팝업 정리
				confirm.close();
				closeGameOverWindows();

				// ① 서버에 수락 알림 (통계/로그용)
				Message acc = new Message();
				acc.type = MessageType.REMATCH_ACCEPT;
				acc.username = currentUsername;   // 수락자
				acc.message  = m.username;        // 최초 요청자
				clientConnection.send(acc);

				// ② "나도 매칭 큐에 넣기" ‑> 양쪽 모두 MATCH_FOUND를 보장
				clientConnection.send(Message.fromMatchRequest(currentUsername));
			}
		});
	}


	/* -------------------------------- */
	/*          GAME  UTILITIES         */
	/* -------------------------------- */
	private void startTimer() {
		if (clock[0] != null) clock[0].stop();
		timeLeft[0] = 40; refreshHeader();
		KeyFrame kf = new KeyFrame(Duration.seconds(1), e -> {
			if (gameDone) { clock[0].stop(); return; }
			timeLeft[0]--; if (timeLeft[0] <= 0) { clock[0].stop(); localEnd("Time’s up – you lose!"); return; }
			refreshHeader();
		});
		clock[0] = new Timeline(kf); clock[0].setCycleCount(Timeline.INDEFINITE); clock[0].play();
	}

	private void refreshHeader() {
		timerLabel.setText("Time: " + String.format("%02d", timeLeft[0]) + (isMyTurn[0] ? "  (Your Turn)" : "  (Opponent Turn)"));
		selfLabel.setText(currentUsername != null ? currentUsername : "");
		oppLabel.setText(currentOpponent != null ? currentOpponent : "");
	}

	private void gameScene(String you, String opp, boolean yourTurn) {
		currentOpponent = opp; isMyTurn[0] = yourTurn; gameDone = false; timeLeft[0] = 40;
		discs = new Circle[6][7];
		GridPane board = new GridPane();
		board.setHgap(5);
		board.setVgap(5);
		board.setPadding(new Insets(10));

		for (int r = 0; r < 6; r++) {
			for (int c = 0; c < 7; c++) {
				Circle d = new Circle(25, Color.LIGHTGRAY);
				d.setStroke(Color.BLACK);
				discs[r][c] = d;
				StackPane cell = new StackPane(d);
				cell.setPrefSize(60, 60);
				final int col = c;

				cell.setOnMouseClicked(e -> {
					if (!isMyTurn[0] || gameDone) return;
					for (int row = 5; row >= 0; row--) {
						if (discs[row][col].getFill() == Color.LIGHTGRAY) {
							discs[row][col].setFill(myColor);
							isMyTurn[0] = false;
							setBoard(false);
							if (clock[0] != null) clock[0].stop();
							clientConnection.sendMove(col, you);
							break;
						}
					}
				});

				board.add(cell, c, r);
				cellPane[r][c] = cell;
			}
		}

		chatList.getItems().setAll("💬 Chat started!");
		chatList.setPrefHeight(150);

		Button sendBtn = new Button("Send");
		sendBtn.disableProperty().bind(inputField.textProperty().isEmpty());
		sendBtn.setOnAction(e -> {
			String txt = inputField.getText().trim();
			sendChat(txt);
			inputField.clear();
		});
		inputField.setOnAction(e -> sendBtn.fire());

		surrenderBtn = new Button("🏳️ Surrender");
		surrenderBtn.setOnAction(e -> {
			localEnd("You surrendered.");
			clientConnection.send(new Message(MessageType.GAME_WIN, opp, "has won by forfeit!"));
		});

		HBox header = new HBox(selfLabel, new Region(), timerLabel, new Region(), oppLabel);
		HBox.setHgrow(header.getChildren().get(1), Priority.ALWAYS);
		HBox.setHgrow(header.getChildren().get(3), Priority.ALWAYS);
		header.setAlignment(Pos.CENTER);
		header.setPadding(new Insets(5, 10, 5, 10));

		HBox chatCtl = new HBox(10, inputField, sendBtn, surrenderBtn);
		chatCtl.setPadding(new Insets(10));

		VBox root = new VBox(10, header, board, chatList, chatCtl);
		root.setPadding(new Insets(10));
		window.setScene(new Scene(root, 600, 700));
		setBoard(yourTurn);
		refreshHeader();

		// 🔥 바로 여기에서 타이머를 즉시 시작하도록 추가!
		if (yourTurn) {
			startTimer();
		}
	}


	private void opponentMove(String move) {
		if (gameDone) return;
		try {
			System.out.println(">>> Opponent move received: " + move);
			String[] parts = move.split(",");
			int row = Integer.parseInt(parts[0]);
			int col = Integer.parseInt(parts[1]);

			discs[row][col].setFill(oppColor);

			// 🔥 반드시 아래 세 줄이 있어야 턴이 정확히 넘어갑니다!
			isMyTurn[0] = true;
			setBoard(true);    // 보드 활성화
			startTimer();      // 즉시 타이머 시작

			refreshHeader();   // 헤더 업데이트 (턴 표시 정확히 갱신)
		} catch (Exception ex) {
			System.err.println("Bad MOVE_MADE message: " + move);
		}
	}

	private void localEnd(String header){
		if(gameDone) return;
		gameDone = true;
		setBoard(false);
		if(clock[0]!=null) clock[0].stop();
		Alert a = new Alert(Alert.AlertType.INFORMATION);
		a.setTitle("Game Over");
		a.setHeaderText(header);
		ButtonType again = new ButtonType("Play Again", ButtonBar.ButtonData.OK_DONE);
		ButtonType quit  = new ButtonType("Quit to Main", ButtonBar.ButtonData.CANCEL_CLOSE);
		a.getButtonTypes().setAll(again,quit);
		Optional<ButtonType> res = a.showAndWait();
		if(res.isPresent() && res.get()==again){
			Message rem = new Message(); rem.type = MessageType.REMATCH_REQUEST; rem.username=currentUsername; rem.message=currentOpponent; clientConnection.send(rem);
		} else window.setScene(mainMenuScene);
	}

	private void setBoard(boolean on) {
		for (StackPane[] row : cellPane) {
			for (StackPane p : row) {
				if (p != null) {
					p.setDisable(!on);
					p.setOpacity(on ? 1.0 : 0.6);
				}
			}
		}
		surrenderBtn.setDisable(!on); // Surrender 버튼만 활성화 여부 설정

		// 🔥 채팅창 항상 활성화
		inputField.setDisable(false);
		chatList.setDisable(false);
	}

	/* -------------------------------- */
	/*           AUTH & MISC            */
	/* -------------------------------- */
	private void auth(boolean signUp) {
		String u = userField.getText().trim();
		String p = passField.getText().trim();

		if (u.isEmpty() || p.isEmpty()) {
			statusLabel.setText("Username and password cannot be empty.");
			return;
		}

		if (clientConnection == null || !clientConnection.isAlive()) {
			clientConnection = new Client(msg -> Platform.runLater(() -> onServer(msg)));
			clientConnection.start();
			try { Thread.sleep(100); } catch (InterruptedException ignored) {}
		}

		Message authMsg = new Message();
		authMsg.type = signUp ? MessageType.SIGNUP : MessageType.LOGIN;
		authMsg.username = u;
		authMsg.password = p;

		clientConnection.send(authMsg);
	}
}
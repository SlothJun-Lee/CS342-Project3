import java.io.Serializable;
import java.util.List;

public class Message implements Serializable {
    static final long serialVersionUID = 42L;

    public MessageType type;
    public String message;
    public int recipient;
    public String sender;
    public String username;
    public String password;

    public List<String> gameHistory;
    public int totalGames;
    public int totalWins;



    public Message(int id, boolean connect) {
        this.recipient = id;
        this.type = connect ? MessageType.NEWUSER : MessageType.DISCONNECT;
    }

    public Message(String systemMessage) {
        this.type = MessageType.TEXT;
        this.message = systemMessage;
        this.recipient = -1;
    }

    public Message(int recipient, String message, String sender) {
        this.type = MessageType.TEXT;
        this.recipient = recipient;
        this.message = message;
        this.sender = sender;
    }

    public Message(MessageType type, String username, String password) {
        this.type = type;
        this.username = username;
        this.password = password;
    }

    public Message(MessageType type, String username, String message, String sender, int recipient) {
        this.type = type;
        this.username = username;
        this.message = message;
        this.sender = sender;
        this.recipient = recipient;
    }
    public Message(MessageType type, String username, String message, String sender) {
        this.type = type;
        this.username = username;
        this.message = message;
        this.sender = sender;
    }
    public static Message fromAuth(MessageType type, String username) {
        Message m = new Message();
        m.type = type;
        m.username = username;
        return m;
    }

    public static Message fromInvite(MessageType type, String sender, String recipient) {
        Message m = new Message();
        m.type = type;
        m.sender = sender;
        m.username = sender;     // ★ 추가: 요청자 이름을 username 에도 담아줌
        m.message = recipient;   // payload = 상대 이름
        return m;
    }

    public static Message fromMatchRequest(String username) {
        Message m = new Message();
        m.type = MessageType.MATCH_REQUEST;
        m.username = username;
        return m;
    }

    public static Message fromMatchFound(String username, String opponent, boolean yourTurn) {
        Message m = new Message();
        m.type = MessageType.MATCH_FOUND;
        m.username = username;
        m.message = opponent;
        m.recipient = yourTurn ? 1 : 0;
        return m;
    }

    public static Message fromText(String sender, String msg) {
        Message m = new Message();
        m.type = MessageType.TEXT;
        m.sender = sender;
        m.username = sender;
        m.message = msg;
        return m;
    }

    public Message() {}
}

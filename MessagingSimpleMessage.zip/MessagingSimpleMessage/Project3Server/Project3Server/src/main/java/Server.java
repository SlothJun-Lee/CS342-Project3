import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class Server {
	ArrayList<ClientThread> clients = new ArrayList<>();
	Map<String, ClientThread> clientMap = new ConcurrentHashMap<>();
	Map<String, String> credentials = new HashMap<>();
	Map<String, Set<String>> friends = new HashMap<>();
	Map<String, GameSession> activeGames = new HashMap<>();
	Queue<ClientThread> matchQueue = new LinkedList<>();

	private final Map<String, PlayerStats> stats = new ConcurrentHashMap<>();
	private static final File STATS_FILE = new File("stats.ser");
	private static final File CREDS_FILE = new File("creds.ser");
	private static final File FRIENDS_FILE = new File("friends.ser");

	private final Consumer<Message> callback;

	private void saveStats() {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(STATS_FILE))) {
			oos.writeObject(stats);
			callback.accept(new Message("[SERVER] Stats saved"));
		} catch (Exception ex) {
			callback.accept(new Message("[SERVER ERROR] Stats save failed: " + ex));
		}
	}

	private void saveFriends() {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FRIENDS_FILE))) {
			oos.writeObject(friends);
			callback.accept(new Message("[SERVER] Friends saved"));
		} catch (Exception ex) {
			callback.accept(new Message("[SERVER ERROR] Friends save failed: " + ex));
		}
	}

	@SuppressWarnings("unchecked")
	private void loadFriends() {
		if (!FRIENDS_FILE.exists()) return;
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FRIENDS_FILE))) {
			friends.putAll((Map<String, Set<String>>) ois.readObject());
			callback.accept(new Message("[SERVER] Friends loaded"));
		} catch (Exception ex) {
			callback.accept(new Message("[SERVER ERROR] Friends load failed: " + ex));
		}
	}

	@SuppressWarnings("unchecked")
	private void loadStats() {
		if (!STATS_FILE.exists()) return;
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(STATS_FILE))) {
			stats.putAll((Map<String, PlayerStats>) ois.readObject());
			callback.accept(new Message("[SERVER] Stats loaded (" + stats.size() + " players)"));
		} catch (Exception ex) {
			callback.accept(new Message("[SERVER ERROR] Stats load failed: " + ex));
		}
	}

	private void endGame(GameSession g, String winner, boolean isWin) {
		String p1 = g.player1;
		String p2 = g.player2;

		// 두 플레이어의 기록을 stats에 등록
		stats.putIfAbsent(p1, new PlayerStats());
		stats.putIfAbsent(p2, new PlayerStats());

		if (winner != null) {
			stats.get(winner).addResult(true, winner.equals(p1) ? p2 : p1);  // 승자 기록
			stats.get(winner.equals(p1) ? p2 : p1).addResult(false, winner); // 패자 기록
		} else {
			// 무승부 처리
			stats.get(p1).addResult(false, p2);
			stats.get(p2).addResult(false, p1);
		}

		saveStats();  // 즉시 파일에 기록 저장

		// 플레이어들에게 결과 알림
		for (String p : Arrays.asList(p1, p2)) {
			ClientThread ct = clientMap.get(p);
			if (ct != null) {
				Message m = new Message();
				m.type = isWin ? MessageType.GAME_WIN : MessageType.GAME_DRAW;
				m.username = winner;
				try {
					ct.out.writeObject(m);
				} catch (Exception ignored) {}
			}
			activeGames.remove(p);
		}

		// 서버 로그 출력
		callback.accept(new Message(isWin ? "[GAME_END] Winner=" + winner : "[GAME_END] Draw"));
	}

	public Server(Consumer<Message> cb) {
		this.callback = cb;
		loadStats();
		loadCreds();
		loadFriends(); // 추가
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			saveStats();
			saveCreds();
			saveFriends(); // 추가
		}));
		new TheServer().start();
	}

	class TheServer extends Thread {
		public void run() {
			try (ServerSocket ss = new ServerSocket(5555)) {
				callback.accept(new Message("[SERVER] Listening on 5555"));
				while (true) {
					Socket sock = ss.accept();
					ClientThread ct = new ClientThread(sock);
					ct.start();
					clients.add(ct);
				}
			} catch (IOException e) {
				callback.accept(new Message("Server failed: " + e.getMessage()));
			}
		}
	}

	static class GameRecord implements Serializable {
		final boolean win; final String opponent;
		GameRecord(boolean win, String opp) { this.win = win; this.opponent = opp; }
	}

	static class PlayerStats implements Serializable {
		int wins, losses;
		final Deque<GameRecord> recent = new ArrayDeque<>(5);

		void addResult(boolean win, String opp) {
			if (win) wins++; else losses++;
			if (recent.size() == 5) recent.removeLast();
			recent.addFirst(new GameRecord(win, opp));
		}
	}

	class GameSession {
		String player1, player2, current;
		String[][] board = new String[6][7];
		int moves = 0;

		GameSession(String p1, String p2) { player1 = p1; player2 = p2; current = p1; }

		int findRow(int col) {
			for (int r = 5; r >= 0; r--)
				if (board[r][col] == null) return r;
			return -1;
		}

		boolean makeMove(String player, int col) {
			if (!player.equals(current)) return false;
			int row = findRow(col);
			if (row == -1) return false;
			board[row][col] = player;
			moves++;
			current = current.equals(player1) ? player2 : player1;
			return true;
		}






		boolean checkWin(int r, int c, String p) {
			return count(r,c,0,1,p)+count(r,c,0,-1,p)>2 ||
					count(r,c,1,0,p)+count(r,c,-1,0,p)>2 ||
					count(r,c,1,1,p)+count(r,c,-1,-1,p)>2 ||
					count(r,c,1,-1,p)+count(r,c,-1,1,p)>2;
		}

		int count(int r, int c, int dr, int dc, String p) {
			int cnt = 0; r+=dr; c+=dc;
			while (r>=0&&r<6&&c>=0&&c<7&&p.equals(board[r][c])){ cnt++; r+=dr;c+=dc; }
			return cnt;
		}
	}

	class ClientThread extends Thread {
		Socket sock;
		ObjectInputStream in;
		ObjectOutputStream out;
		String username;

		ClientThread(Socket s) { sock = s; }

		public void run() {
			try {
				out = new ObjectOutputStream(sock.getOutputStream());
				in = new ObjectInputStream(sock.getInputStream());
			} catch (Exception ignored) { return; }

			while (true) {
				try {
					Message data = (Message) in.readObject();
					switch (data.type) {
						case LOGIN: handleLogin(data); break;
						case SIGNUP: handleSignup(data); break;
						case MOVE_MADE:
							handleMove(data);   break;
						case TEXT: handleText(data); break;
						case MATCH_REQUEST:
							if (data.message == null || data.message.isEmpty()) { // 랜덤 매칭 요청
								handleMatchRequest(this);
							} else { // 친구 초대 요청
								String friendName = data.message;  // 초대받는 친구 이름
								ClientThread friendThread = clientMap.get(friendName);

								if (friendThread != null && friendThread.sock.isConnected()) {
									Message matchInvite = new Message();
									matchInvite.type = MessageType.MATCH_REQUEST;
									matchInvite.sender = username;
									matchInvite.message = username + " invited you to play a game!";
									friendThread.out.writeObject(matchInvite);
									friendThread.out.flush();
									sendSuccess(username, "Game invitation sent to " + friendName + ".");
									callback.accept(new Message("[초대 발송 성공] " + username + " → " + friendName));
								} else {
									sendFail(username, friendName + " is offline. Invitation failed.");
									callback.accept(new Message("[초대 발송 실패] " + username + " → (오프라인) " + friendName));
								}
							}
							break;
						case STATS_REQUEST:
							handleStatsRequest();
							break;

						case FRIEND_REQUEST: handleFriendRequest(data);          break;
						case FRIEND_ACCEPT:  handleFriendAccept(data);           break;
						case FRIEND_DECLINE: forwardDecline(data);               break;
						case MATCH_ACCEPT:
							ClientThread inviter = clientMap.get(data.sender);  // 초대한 사람 (sender)
							if (inviter != null && inviter.sock.isConnected()) {
								GameSession gs = new GameSession(username, data.sender);
								activeGames.put(username, gs);
								activeGames.put(data.sender, gs);

								// inviter 에게 MATCH_FOUND 메시지 전송 (선 플레이어)
								Message inviterMsg = new Message();
								inviterMsg.type = MessageType.MATCH_FOUND;
								inviterMsg.username = data.sender;       // 초대한 사람 이름
								inviterMsg.message = username;           // 수락한 사람 이름
								inviterMsg.recipient = 1;                // inviter가 선 플레이어

								inviter.out.writeObject(inviterMsg);
								inviter.out.flush();

								// inviter 에게 YOUR_TURN 전송 (명확히 inviter에게 턴 부여)
								Message yourTurnMsg = new Message();
								yourTurnMsg.type = MessageType.YOUR_TURN;
								yourTurnMsg.username = data.sender;     // 초대한 사람에게 턴 명확히 설정
								inviter.out.writeObject(yourTurnMsg);
								inviter.out.flush();

								// 현재 클라이언트에게 MATCH_FOUND (후 플레이어)
								Message accepterMsg = new Message();
								accepterMsg.type = MessageType.MATCH_FOUND;
								accepterMsg.username = username;         // 수락한 사람 이름
								accepterMsg.message = data.sender;       // 초대한 사람 이름
								accepterMsg.recipient = 0;               // accepter는 후 플레이어

								this.out.writeObject(accepterMsg);
								this.out.flush();

								callback.accept(new Message("[게임 시작] " + data.sender + " vs " + username));
							} else {
								sendFail(username, "The inviter (" + data.sender + ") is no longer online.");
							}
							break;
						case REMATCH_REQUEST:
							String opponent = data.message; // 상대방 이름
							ClientThread opponentThread = clientMap.get(opponent);
							if (opponentThread != null && opponentThread.sock.isConnected()) {
								Message rematchInvite = new Message();
								rematchInvite.type = MessageType.REMATCH_REQUEST;
								rematchInvite.sender = username; // 요청자
								opponentThread.out.writeObject(rematchInvite);
								opponentThread.out.flush();
								callback.accept(new Message("[REMATCH_REQUEST] " + username + " → " + opponent));
							} else {
								sendFail(username, opponent + " is offline. Rematch request failed.");
							}
							break;

						case REMATCH_ACCEPT:
							String originalRequester = data.message; // 다시하기 요청한 원래 플레이어
							ClientThread requesterThread = clientMap.get(originalRequester);
							ClientThread accepterThread = this; // 지금 수락한 사람

							if (requesterThread != null && requesterThread.sock.isConnected()) {
								GameSession gs = new GameSession(originalRequester, accepterThread.username);
								activeGames.put(originalRequester, gs);
								activeGames.put(accepterThread.username, gs);

								// 다시하기 요청자 (승자)가 선 플레이어
								Message requesterMsg = Message.fromMatchFound(originalRequester, accepterThread.username, true);
								requesterThread.out.writeObject(requesterMsg);
								requesterThread.out.flush();

								Message requesterYourTurn = new Message();
								requesterYourTurn.type = MessageType.YOUR_TURN;
								requesterYourTurn.username = originalRequester;
								requesterThread.out.writeObject(requesterYourTurn);
								requesterThread.out.flush();

								// 다시하기 수락자 (패자)는 후 플레이어
								Message accepterMsg = Message.fromMatchFound(accepterThread.username, originalRequester, false);
								accepterThread.out.writeObject(accepterMsg);
								accepterThread.out.flush();

								callback.accept(new Message("[REMATCH] " + originalRequester + " vs " + accepterThread.username));
							} else {
								sendFail(accepterThread.username, originalRequester + " is offline. Rematch failed.");
							}
							break;




						case MATCH_DECLINE:
							ClientThread inviterThread = clientMap.get(data.sender);
							if (inviterThread != null) {
								Message declineNotice = new Message();
								declineNotice.type = MessageType.TEXT;
								declineNotice.username = "SERVER";
								declineNotice.message = username + " declined your game invitation.";
								inviterThread.out.writeObject(declineNotice);
								inviterThread.out.flush();
							}
							break;
						// other cases...
					}
				} catch (Exception ex) {
					handleDisconnect();
					break;
				}
			}
		}
		private void handleStatsRequest() throws IOException {
			PlayerStats ps = stats.getOrDefault(username, new PlayerStats());

			StringBuilder sb = new StringBuilder(ps.wins + "," + ps.losses);
			for (GameRecord gr : ps.recent) {
				sb.append(";").append(gr.win).append(",").append(gr.opponent);
			}

			Message reply = new Message();
			reply.type = MessageType.STATS_REPLY;
			reply.username = username;
			reply.message = sb.toString();

			out.writeObject(reply);
			out.flush();
		}

		private void handleLogin(Message d) throws IOException {
			System.out.println("[로그인 시도] username=" + d.username + ", password=" + d.password);

			if (!credentials.containsKey(d.username)) {
				Message failMsg = new Message();
				failMsg.type = MessageType.LOGIN_FAIL;
				failMsg.username = d.username;
				failMsg.message = "User does not exist.";  // 🔥 "message" 필드를 반드시 사용
				out.writeObject(failMsg);
				callback.accept(new Message("[LOGIN 실패] 존재하지 않는 유저: " + d.username));
				return;
			}

			if (!credentials.get(d.username).equals(d.password)) {
				Message failMsg = new Message();
				failMsg.type = MessageType.LOGIN_FAIL;
				failMsg.username = d.username;
				failMsg.message = "Wrong password.";  // 🔥 "message" 필드를 반드시 사용
				out.writeObject(failMsg);
				callback.accept(new Message("[LOGIN 실패] 잘못된 비밀번호: " + d.username));
				return;
			}

			if(clientMap.containsKey(d.username)) {
				ClientThread oldThread = clientMap.get(d.username);
				oldThread.handleDisconnect();
			}

			this.username = d.username;
			clientMap.put(username, this);

			out.writeObject(new Message(MessageType.LOGIN_SUCCESS, username, ""));
			callback.accept(new Message("[LOGIN SUCCESS] " + username));
			broadcastOnlineUsers();

			Set<String> myFriends = friends.getOrDefault(username, new HashSet<>());

			Message friendListMsg = new Message();
			friendListMsg.type = MessageType.FRIEND_LIST;
			friendListMsg.gameHistory = new ArrayList<>(myFriends);
			out.writeObject(friendListMsg);
			out.flush();

			for (String f : myFriends) {
				notifyOnlineStatus(username, f, true);
			}

			for (String friend : myFriends) {
				boolean isFriendOnline = clientMap.containsKey(friend);
				Message onlineUpdateMsg = new Message();
				onlineUpdateMsg.type = MessageType.ONLINE_UPDATE;
				onlineUpdateMsg.username = friend;
				onlineUpdateMsg.recipient = isFriendOnline ? 1 : 0;
				out.writeObject(onlineUpdateMsg);
				out.flush();
			}
		}

		private void sendSuccess(String user, String txt) throws IOException {
			ClientThread ct = clientMap.get(user);
			if (ct == null) return;
			Message m = new Message();
			m.type = MessageType.TEXT;
			m.username = "SERVER";
			m.message = txt;
			ct.out.writeObject(m);
			ct.out.flush();
		}


		private void handleMove(Message d) throws IOException {
			GameSession g = activeGames.get(username);
			if (g == null) return;

			int col = Integer.parseInt(d.message);
			int row = g.findRow(col);

			if (g.makeMove(username, col)) {
				String opponent = g.player1.equals(username) ? g.player2 : g.player1;
				ClientThread other = clientMap.get(opponent);

				if (other != null) {
					// 상대에게 MOVE_MADE 메시지 전송
					Message mv = new Message();
					mv.type = MessageType.MOVE_MADE;
					mv.username = username;
					mv.message = row + "," + col;
					other.out.writeObject(mv);

					// 상대에게 YOUR_TURN 메시지 명확히 전달 (반드시 추가!)
					Message yourTurnMsg = new Message();
					yourTurnMsg.type = MessageType.YOUR_TURN;
					yourTurnMsg.username = opponent;
					other.out.writeObject(yourTurnMsg);
					other.out.flush();
				}

				if (g.checkWin(row, col, username)) {
					endGame(g, username, true);
				} else if (g.moves == 42) {
					endGame(g, null, false);
				}
			}
		}
		private void handleFriendRequest(Message d) throws IOException {
			String requester = d.sender; // 친구 요청 보낸 사람
			String target = d.message;   // 친구 요청 받을 사람

			System.out.println("친구 요청 [" + requester + " → " + target + "]");
			System.out.println("온라인 유저 목록: " + clientMap.keySet());

			if (requester == null || target == null) {
				sendFail(requester, "친구 요청 정보가 잘못되었습니다.");
				return;
			}

			if (requester.equals(target)) {
				sendFail(requester, "자기 자신은 추가할 수 없습니다");
				return;
			}

			friends.putIfAbsent(requester, new HashSet<>());
			friends.putIfAbsent(target, new HashSet<>());

			if (friends.get(requester).contains(target)) {
				sendFail(requester, "이미 친구입니다");
				return;
			}

			ClientThread tgt = clientMap.get(target);
			if (tgt == null) {
				sendFail(requester, "상대가 오프라인입니다");
				System.out.println("상대가 오프라인 상태로 판정되었습니다.");
				return;
			}

			System.out.println("✅ 친구 요청 정상 전달 시도 중... to: " + target);

			Message friendReqMsg = new Message();
			friendReqMsg.type = MessageType.FRIEND_REQUEST;
			friendReqMsg.sender = requester; // 요청자
			friendReqMsg.message = "Friend request from " + requester;

			tgt.out.writeObject(friendReqMsg);
			tgt.out.flush();

			callback.accept(new Message("[FRIEND_REQUEST] " + requester + " → " + target));
		}




		private void handleFriendAccept(Message d) throws IOException {
			friends.get(d.username).add(d.message);
			friends.get(d.message).add(d.username);

			notifyOnlineStatus(d.username, d.message, clientMap.containsKey(d.message));
			notifyOnlineStatus(d.message, d.username, clientMap.containsKey(d.username));

			Message ok = new Message();
			ok.type = MessageType.FRIEND_ACCEPT;
			ok.username = d.username;
			ok.message = d.message;
			clientMap.get(d.message).out.writeObject(ok);
			clientMap.get(d.username).out.writeObject(ok);
		}

		private void forwardDecline(Message d) throws IOException {

			ClientThread req = clientMap.get(d.message);     // 최초 요청자
			if (req == null) return;

			Message r = new Message();
			r.type = MessageType.FRIEND_DECLINE;
			r.username = d.username;                         // 거절한 사람
			req.out.writeObject(r);

			callback.accept(new Message("[FRIEND_DECLINE] " + d.username + " ✖ " + d.message));
		}

		private void sendFail(String user,String txt) throws IOException{
			ClientThread ct=clientMap.get(user);
			if(ct==null) return;
			Message m=new Message(); m.type=MessageType.TEXT; m.username="SERVER"; m.message=txt;
			ct.out.writeObject(m);
		}

		private void notifyOnlineStatus(String friend, String to, boolean online) {
			ClientThread ct = clientMap.get(to);
			if (ct != null) {
				try {
					Message update = new Message();
					update.type = MessageType.ONLINE_UPDATE;
					update.username = friend;
					update.recipient = online ? 1 : 0;
					ct.out.writeObject(update);
					ct.out.flush();
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
		}

		private void handleSignup(Message d) throws IOException {
			System.out.println("[회원가입 시도] username=" + d.username);

			if (credentials.containsKey(d.username)) {
				Message failMsg = new Message();
				failMsg.type = MessageType.SIGNUP_FAIL;
				failMsg.username = d.username;
				failMsg.message = "Username already exists.";  // 🔥 message 필드 반드시 사용
				out.writeObject(failMsg);
				callback.accept(new Message("[SIGNUP 실패] 중복된 유저: " + d.username));
				return;
			}

			credentials.put(d.username, d.password);
			friends.put(d.username, new HashSet<>());
			this.username = d.username;
			clientMap.put(username, this);
			out.writeObject(new Message(MessageType.SIGNUP_SUCCESS, username, ""));
			callback.accept(new Message("[SIGNUP 성공] " + username));
			broadcastOnlineUsers();

			Set<String> myFriends = friends.getOrDefault(username, new HashSet<>());
			Message friendListMsg = new Message();
			friendListMsg.type = MessageType.FRIEND_LIST;
			friendListMsg.gameHistory = new ArrayList<>(myFriends);
			out.writeObject(friendListMsg);
			out.flush();
		}


		void handleDisconnect() {
			System.out.println("User disconnected: " + username);

			if (username != null) {   // 🔥 username null 체크 필수!
				clientMap.remove(username);
			}
			clients.remove(this);

			Set<String> myFriends = friends.getOrDefault(username, new HashSet<>());
			for (String friend : myFriends) {
				notifyOnlineStatus(username, friend, false);
			}

			try {
				sock.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		private void handleText(Message d) throws IOException {
			GameSession g = activeGames.get(d.username); // ★★★ username 필드를 사용해야 함
			if (g == null) return;

			String target = g.player1.equals(d.username) ? g.player2 : g.player1;
			ClientThread other = clientMap.get(target);
			if (other == null) return;

			Message fwd = new Message();
			fwd.type = MessageType.TEXT;
			fwd.username = d.username;  // ★★★ sender가 아닌 username 사용!
			fwd.message = d.message;

			other.out.writeObject(fwd);
			other.out.flush();

			callback.accept(new Message("[CHAT] " + d.username + " → " + target + " : " + d.message));
		}
	}

	private void broadcastOnlineUsers() {
		String onlineUsers = String.join(",", clientMap.keySet());
		for (ClientThread ct : clientMap.values()) {
			try {
				ct.out.writeObject(new Message(MessageType.NEWUSER, "SERVER", onlineUsers));
			} catch (IOException ignored) {}
		}
	}

	private void handleMatchRequest(ClientThread requester) throws IOException {
		// 이미 대기열에 있는지 체크해서 자기 자신과 매칭되는 것 방지
		if (matchQueue.contains(requester)) {
			return; // 이미 매칭 대기 중이면 무시
		}

		matchQueue.offer(requester);

		if (matchQueue.size() >= 2) {
			ClientThread player1 = matchQueue.poll();
			ClientThread player2 = matchQueue.poll();

			// 자기 자신과 매칭되는 상황 방지
			if (player1 == player2) {
				matchQueue.offer(player1); // 하나만 빼서 자기자신이면 다시 넣음
				return;
			}

			GameSession gs = new GameSession(player1.username, player2.username);
			activeGames.put(player1.username, gs);
			activeGames.put(player2.username, gs);

			// player1에게 MATCH_FOUND 메시지 (선 플레이어 설정)
			Message player1Msg = new Message();
			player1Msg.type = MessageType.MATCH_FOUND;
			player1Msg.username = player1.username;
			player1Msg.message = player2.username;
			player1Msg.recipient = 1; // player1이 선 플레이어

			player1.out.writeObject(player1Msg);
			player1.out.flush();

			// player1에게 YOUR_TURN 추가 전송
			Message yourTurn = new Message();
			yourTurn.type = MessageType.YOUR_TURN;
			yourTurn.username = player1.username;
			player1.out.writeObject(yourTurn);
			player1.out.flush();

			// player2에게 MATCH_FOUND 메시지 (후 플레이어 설정)
			Message player2Msg = new Message();
			player2Msg.type = MessageType.MATCH_FOUND;
			player2Msg.username = player2.username;
			player2Msg.message = player1.username;
			player2Msg.recipient = 0; // player2가 후 플레이어

			player2.out.writeObject(player2Msg);
			player2.out.flush();

			callback.accept(new Message("[RANDOM_MATCH] " + player1.username + " vs " + player2.username));
		}
	}




	private void loadCreds() {
		if (!CREDS_FILE.exists()) return;
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(CREDS_FILE))) {
			credentials.putAll((Map<String, String>) ois.readObject());
		} catch (Exception ignored) {}
	}

	private void saveCreds() {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CREDS_FILE))) {
			oos.writeObject(credentials);
		} catch (IOException ignored) {}
	}
}
